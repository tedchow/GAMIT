import csv 
import pandas as pd
import numpy as np
adj_mat = pd.read_csv('adj_mat.csv', header=None)
print(adj_mat.shape)
adj_np = adj_mat.values
print(adj_np.shape)
adj_np [adj_np !=0] = 1
Iden = np.eye(adj_np.shape[0])
# print(adj_np)
adj_np = adj_np - Iden
for i in range(adj_np.shape[0]):
	for j in range(i+1, adj_np.shape[0]):
		if adj_np[i].all == adj_np[j].all:
			print('1')

